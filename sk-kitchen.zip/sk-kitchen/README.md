# SK KITCHEN – Wada Pav & Momos Special
WhatsApp food-ordering website + owner admin panel. Runs free on Netlify (static site + 1 serverless function + built-in Netlify Blobs database). No payment gateway, no customer login.

## What you get
- **Customer site** (`/`): menu with Veg/Non-Veg marks, Today's Special, offers, cart, automatic totals, delivery rules, coupon code, order summary, **Place Order on WhatsApp** (pre-formatted message to 7738681855).
- **Owner panel** (`/admin`): login, menu (add/edit/delete, photos, prices, veg/non-veg, availability, categories), offers, delivery settings, website settings, backup/restore. Built for a phone screen.
- **Database**: Netlify Blobs (automatic, nothing to configure). Photos are stored there too.
- **Security**: the owner password lives only in a Netlify environment variable (never in the website code). Login returns a signed token; every change is checked on the server; wrong-password lockout after 5 tries.

## Deploy (about 10 minutes, free)
Netlify "drag and drop" does **not** run the API, so deploy from GitHub (or the CLI).

1. Create a free account at github.com, then **New repository** (e.g. `sk-kitchen`, Private is fine).
2. Upload everything from this folder (unzipped) into the repository, keeping the folder structure (`public/`, `netlify/`, `netlify.toml`, `package.json`). On a phone, GitHub's "Add file → Upload files" works best in desktop-site mode.
3. Create a free account at netlify.com, then **Add new site → Import an existing project → GitHub** and choose the repo. Build settings are read from `netlify.toml`; just click **Deploy**.
4. **Set the owner password (required):** Site configuration → Environment variables → **Add a variable**
   - Key `ADMIN_PASSWORD`, Value = a strong password only you know.
   - Optional: `TOKEN_SECRET` = any long random text (makes login tokens extra safe).
5. **Deploys → Trigger deploy → Deploy site** (so the password takes effect).
6. Open `https://YOUR-SITE.netlify.app/admin` and log in. In Chrome on Android: ⋮ → **Add to Home screen** for one-tap access.

*Using the CLI instead:* `npm i -g netlify-cli && netlify login && netlify deploy --prod` (set `ADMIN_PASSWORD` in the Netlify dashboard first).

Change the site name/URL: Site configuration → Change site name. Change the owner password later: edit `ADMIN_PASSWORD` there and redeploy.

## First things to do in the admin panel
1. **Website tab**: check opening hours (set to 10 AM – 10 PM as a placeholder), Google Maps link, banner text/photo.
2. **Menu tab**: tap ✏️ on each item to upload a real food photo (until then a food emoji is shown).
3. **Offers tab**: review the Diwali Dhamaka offers (see below).

## How offers work
Types: **% off**, **₹ off**, **Buy X Get Y Free**, **Combo price** (e.g. 3 for ₹60). Each offer can apply to all items or selected items, have a minimum order, start/end dates (inclusive), an optional coupon code, and an ON/OFF switch.
- Buy-X-Get-Y and combo offers apply per product (best one per product; they add up across products).
- Only the single best % / ₹ offer applies (they don't stack).
- Offers with a coupon code apply only when the customer types the code.
- The free-delivery limit is checked on the item subtotal *before* discounts.

Pre-loaded: Diwali Dhamaka (1–10 Nov 2026): 3 Veg Crispy Wada Pav ₹60, 3 Veg Steam Momos ₹150, 3 Chicken Steam Momos ₹210. They show as "Starts 1 Nov" until then. A "3 Chicken Wada Pav for ₹90" combo would cost *more* than 3 × ₹25 = ₹75, so it was not added; create it from the Offers tab if you meant a different item or price.

## Delivery rules (Delivery tab)
Default: free delivery at ₹199+, ₹30 below, within 8 KM. All editable, plus a switch to turn home delivery off (customers can still choose Self Pickup).

## Try it on your computer
`npm install` then `npm run dev` → http://localhost:8888 (admin password `test1234`, data resets when stopped). `npm test` runs the checks.

## Files
```
public/index.html, admin.html       pages
public/css/style.css, admin.css     design
public/js/app.js                    storefront (cart, WhatsApp message)
public/js/admin.js                  owner panel
public/js/pricing.js                offer + delivery maths
public/defaults.json                offline fallback copy of starting data
netlify/functions/api.mjs           API entry (Netlify Blobs database)
netlify/functions/lib/core.mjs      login, validation, save, photo upload
netlify/functions/lib/defaults.mjs  starting menu/offers/settings
netlify.toml, package.json          config
test/                               tests + local preview server
```
