// Local preview: node test/dev-server.mjs   → http://localhost:8888
// Uses an in-memory database (resets when stopped). Owner password: ADMIN_PASSWORD env or "test1234".
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createHandler } from "../netlify/functions/lib/core.mjs";
import { memStores } from "./mem.mjs";

process.env.ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "test1234";
const root = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "public");
const handler = createHandler(() => stores);
const stores = memStores();
const types = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".json": "application/json", ".svg": "image/svg+xml" };

http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://localhost");
  if (url.pathname.startsWith("/api/")) {
    const chunks = [];
    for await (const c of req) chunks.push(c);
    const body = chunks.length ? Buffer.concat(chunks) : undefined;
    const r = await handler(new Request(url, { method: req.method, headers: req.headers, body: ["GET", "HEAD"].includes(req.method) ? undefined : body }), { ip: "127.0.0.1" });
    res.writeHead(r.status, Object.fromEntries(r.headers));
    return res.end(Buffer.from(await r.arrayBuffer()));
  }
  let p = url.pathname === "/" ? "/index.html" : url.pathname === "/admin" ? "/admin.html" : url.pathname;
  const file = path.join(root, path.normalize(p));
  if (!file.startsWith(root) || !fs.existsSync(file)) { res.writeHead(404); return res.end("Not found"); }
  res.writeHead(200, { "content-type": types[path.extname(file)] || "application/octet-stream" });
  fs.createReadStream(file).pipe(res);
}).listen(process.env.PORT || 8888, () => console.log("Preview on http://localhost:" + (process.env.PORT || 8888)));
