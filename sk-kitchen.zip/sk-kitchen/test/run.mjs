import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { createHandler, sanitize } from "../netlify/functions/lib/core.mjs";
import { DEFAULTS } from "../netlify/functions/lib/defaults.mjs";
import { memStores } from "./mem.mjs";

const require = createRequire(import.meta.url);
const P = require("../public/js/pricing.js");
let n = 0;
const ok = (name, fn) => Promise.resolve().then(fn).then(() => { n++; console.log("  ✓", name); });

const item = (id) => DEFAULTS.items.find((i) => i.id === id);
const L = (...pairs) => pairs.map(([id, qty]) => ({ item: item(id), qty }));
const data = (offers) => ({ ...DEFAULTS, offers });
const off = (o) => ({ id: "o", title: "T", description: "", type: "percent", value: 0, buy: 0, get: 0, minOrder: 0, productIds: [], start: "", end: "", code: "", enabled: true, ...o });

console.log("Pricing");
await ok("subtotal & no offers", () => {
  const c = P.calc(L(["veg-crispy", 2], ["veg-steam-momos", 1]), data([]), {});
  assert.equal(c.subtotal, 110); assert.equal(c.discount, 0);
});
await ok("diwali bundles: 3 veg wada pav = ₹60 (saves 15)", () => {
  const c = P.calc(L(["veg-crispy", 3]), DEFAULTS, { today: "2026-11-05" });
  assert.equal(c.discount, 15);
});
await ok("bundle: 7 momos plates = 2 bundles (saves 60)", () => {
  const c = P.calc(L(["veg-steam-momos", 7]), DEFAULTS, { today: "2026-11-05" });
  assert.equal(c.discount, 60);
});
await ok("bundle not active before start / after end", () => {
  assert.equal(P.calc(L(["veg-crispy", 3]), DEFAULTS, { today: "2026-10-31" }).discount, 0);
  assert.equal(P.calc(L(["veg-crispy", 3]), DEFAULTS, { today: "2026-11-11" }).discount, 0);
  assert.equal(P.calc(L(["veg-crispy", 3]), DEFAULTS, { today: "2026-11-10" }).discount, 15);
});
await ok("buy 2 get 1 free on selected product only", () => {
  const d = data([off({ type: "bxgy", buy: 2, get: 1, productIds: ["chicken-wp"] })]);
  assert.equal(P.calc(L(["chicken-wp", 3]), d, {}).discount, 25);
  assert.equal(P.calc(L(["chicken-wp", 2]), d, {}).discount, 0);
  assert.equal(P.calc(L(["veg-crispy", 3]), d, {}).discount, 0);
  assert.equal(P.calc(L(["chicken-wp", 6]), d, {}).discount, 50);
});
await ok("percent offer with min order", () => {
  const d = data([off({ type: "percent", value: 10, minOrder: 200 })]);
  assert.equal(P.calc(L(["veg-crispy", 4]), d, {}).discount, 0);
  assert.equal(P.calc(L(["veg-steam-momos", 4]), d, {}).discount, 24);
});
await ok("best single percent/flat is used, not stacked", () => {
  const d = data([off({ id: "a", type: "percent", value: 10 }), off({ id: "b", type: "flat", value: 50 })]);
  assert.equal(P.calc(L(["veg-steam-momos", 4]), d, {}).discount, 50);
});
await ok("coupon code required, case-insensitive", () => {
  const d = data([off({ type: "flat", value: 20, code: "SAVE20" })]);
  const l = L(["veg-steam-momos", 2]);
  assert.equal(P.calc(l, d, {}).discount, 0);
  assert.equal(P.calc(l, d, { code: "save20" }).discount, 20);
  assert.equal(P.calc(l, d, { code: "save20" }).codeApplied, true);
  assert.equal(P.calc(l, d, { code: "nope" }).codeMessage, "Invalid or expired code");
});
await ok("disabled offer ignored; discount never exceeds subtotal", () => {
  assert.equal(P.calc(L(["veg-crispy", 1]), data([off({ type: "flat", value: 20, enabled: false })]), {}).discount, 0);
  assert.equal(P.calc(L(["veg-crispy", 1]), data([off({ type: "flat", value: 500 })]), {}).discount, 25);
});
await ok("delivery: free at ₹199+, ₹30 below, pickup free, disabled", () => {
  const d = DEFAULTS.delivery;
  assert.deepEqual(P.delivery(198, "delivery", d), { available: true, free: false, charge: 30, toFree: 1 });
  assert.equal(P.delivery(199, "delivery", d).charge, 0);
  assert.equal(P.delivery(199, "delivery", d).free, true);
  assert.equal(P.delivery(50, "pickup", d).charge, 0);
  assert.equal(P.delivery(50, "delivery", { ...d, enabled: false }).available, false);
});

console.log("API");
process.env.ADMIN_PASSWORD = "s3cret-pass";
const stores = memStores();
const h = createHandler(() => stores);
const call = (path, method = "GET", body, token) =>
  h(new Request("http://x/api/" + path, { method, headers: { "content-type": "application/json", ...(token ? { authorization: "Bearer " + token } : {}) }, body: body ? JSON.stringify(body) : undefined }), { ip: "1.1.1.1" });

let token;
await ok("public GET /data returns defaults", async () => {
  const r = await call("data"); assert.equal(r.status, 200);
  const j = await r.json(); assert.equal(j.items.length, 9); assert.equal(j.settings.whatsapp, "7738681855");
});
await ok("save requires login", async () => {
  assert.equal((await call("save", "POST", DEFAULTS)).status, 401);
  assert.equal((await call("save", "POST", DEFAULTS, "fake.token")).status, 401);
});
await ok("wrong password rejected, right password gives token", async () => {
  assert.equal((await call("login", "POST", { password: "nope" })).status, 401);
  const r = await call("login", "POST", { password: "s3cret-pass" }); assert.equal(r.status, 200);
  token = (await r.json()).token; assert.ok(token.includes("."));
});
await ok("tampered token rejected", async () => {
  const [p, s] = token.split(".");
  const bad = Buffer.from(JSON.stringify({ exp: Date.now() + 9e9 })).toString("base64url") + "." + s;
  assert.equal((await call("save", "POST", DEFAULTS, bad)).status, 401);
});
await ok("save persists & public sees it", async () => {
  const d = structuredClone(DEFAULTS); d.items[0].price = 30; d.settings.name = "SK KITCHEN 2";
  const r = await call("save", "POST", d, token); assert.equal(r.status, 200);
  const j = await (await call("data")).json(); assert.equal(j.items[0].price, 30); assert.equal(j.settings.name, "SK KITCHEN 2");
});
await ok("sanitize drops bad data (script injection, bad refs, bad image urls)", () => {
  const d = structuredClone(DEFAULTS);
  d.items.push({ id: "bad id!", name: "x", price: 1, categoryId: "veg" });
  d.items.push({ id: "ok2", name: "<img src=x onerror=1>", price: "abc", categoryId: "nope" });
  d.items[0].image = "javascript:alert(1)"; d.settings.mapsLink = "javascript:alert(1)"; d.offers[0].productIds = ["ghost", "veg-crispy"];
  const c = sanitize(d);
  assert.equal(c.items.length, 9); assert.equal(c.items[0].image, ""); assert.equal(c.settings.mapsLink, "");
  assert.deepEqual(c.offers[0].productIds, ["veg-crispy"]);
});
await ok("image upload validates type + stores + serves", async () => {
  const png = Buffer.concat([Buffer.from("89504e470d0a1a0a", "hex"), Buffer.alloc(200, 1)]).toString("base64");
  assert.equal((await call("image", "POST", { type: "image/png", data: png })).status, 401);
  assert.equal((await call("image", "POST", { type: "image/jpeg", data: png }, token)).status, 400); // wrong magic bytes
  assert.equal((await call("image", "POST", { type: "text/html", data: png }, token)).status, 400);
  const r = await call("image", "POST", { type: "image/png", data: png }, token); assert.equal(r.status, 200);
  const { url } = await r.json();
  const g = await call(url.replace("/api/", "")); assert.equal(g.status, 200); assert.equal(g.headers.get("content-type"), "image/png");
});
await ok("login locks after 5 wrong attempts", async () => {
  const hh = createHandler(() => memStores());
  let last;
  for (let i = 0; i < 6; i++) last = await hh(new Request("http://x/api/login", { method: "POST", body: JSON.stringify({ password: "x" }) }), { ip: "9.9.9.9" });
  assert.equal(last.status, 429);
});
await ok("login says setup needed when ADMIN_PASSWORD missing", async () => {
  const old = process.env.ADMIN_PASSWORD; delete process.env.ADMIN_PASSWORD;
  const r = await call("login", "POST", { password: "x" }); assert.equal(r.status, 500);
  process.env.ADMIN_PASSWORD = old;
});

console.log(`\nAll ${n} tests passed ✅`);
