// Tiny in-memory stand-in for Netlify Blobs (used by tests and the local dev server).
export function memStore() {
  const m = new Map();
  return {
    async get(k, o) {
      const v = m.get(k);
      if (!v) return null;
      return o && o.type === "json" ? JSON.parse(v.val) : v.val;
    },
    async setJSON(k, v) { m.set(k, { val: JSON.stringify(v) }); },
    async set(k, v, o) { m.set(k, { val: v, meta: o && o.metadata }); },
    async getWithMetadata(k) { const v = m.get(k); return v ? { data: v.val, metadata: v.meta } : null; },
  };
}
export const memStores = () => ({ data: memStore(), images: memStore() });
