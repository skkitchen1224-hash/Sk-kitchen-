/* Offer + delivery maths. Used by the storefront (and unit-tested with Node). */
(function (root) {
  function todayIST() {
    return new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" });
  }

  // status: disabled | scheduled | expired | active
  function offerStatus(o, today) {
    today = today || todayIST();
    if (!o.enabled) return "disabled";
    if (o.start && today < o.start) return "scheduled";
    if (o.end && today > o.end) return "expired";
    return "active";
  }
  function isActive(o, today) {
    return offerStatus(o, today) === "active";
  }
  function applies(o, itemId) {
    return !o.productIds || !o.productIds.length || o.productIds.indexOf(itemId) > -1;
  }

  // Money saved on one cart line by a per-product offer (bxgy / bundle)
  function lineSaving(o, item, qty) {
    if (o.type === "bxgy") {
      var group = (+o.buy || 0) + (+o.get || 0);
      if (group <= 0 || !o.get) return 0;
      return Math.floor(qty / group) * o.get * item.price;
    }
    if (o.type === "bundle") {
      var n = +o.buy || 0;
      if (n <= 0) return 0;
      var save = item.price * n - (+o.value || 0);
      return save > 0 ? Math.floor(qty / n) * save : 0;
    }
    return 0;
  }

  /*
   lines: [{ item:{id,price,...}, qty }]
   Rules:
   - Buy-X-Get-Y and bundle offers: the best one per product is applied (they add up across products).
   - Percent / flat offers: only the single best one is applied.
   - Offers with a coupon code apply only when that code is entered.
   - minOrder is checked against the cart subtotal (before discounts).
  */
  function calc(lines, data, opts) {
    opts = opts || {};
    var code = String(opts.code || "").trim().toUpperCase();
    var today = opts.today || todayIST();
    var subtotal = 0;
    var count = 0;
    lines.forEach(function (l) {
      subtotal += l.item.price * l.qty;
      count += l.qty;
    });

    var active = (data.offers || []).filter(function (o) { return isActive(o, today); });
    var codeOffers = code ? active.filter(function (o) { return o.code && o.code === code; }) : [];
    var codeMessage = "";
    if (code && !codeOffers.length) codeMessage = "Invalid or expired code";

    var usable = active.filter(function (o) {
      if (o.code && o.code !== code) return false;
      if (subtotal < (o.minOrder || 0)) {
        if (o.code && o.code === code) codeMessage = "Add ₹" + (o.minOrder - subtotal) + " more to use this code";
        return false;
      }
      return true;
    });
    if (code && codeOffers.length && !codeMessage) codeMessage = "";

    var parts = {}; // offer id -> {title, amount}
    var perItemTotal = 0;
    var perItem = usable.filter(function (o) { return o.type === "bxgy" || o.type === "bundle"; });
    lines.forEach(function (l) {
      var best = 0, bo = null;
      perItem.forEach(function (o) {
        if (!applies(o, l.item.id)) return;
        var s = lineSaving(o, l.item, l.qty);
        if (s > best) { best = s; bo = o; }
      });
      if (bo) {
        perItemTotal += best;
        parts[bo.id] = parts[bo.id] || { title: bo.title, amount: 0 };
        parts[bo.id].amount += best;
      }
    });

    var bestPF = null;
    usable.forEach(function (o) {
      if (o.type !== "percent" && o.type !== "flat") return;
      var base = 0;
      lines.forEach(function (l) {
        if (applies(o, l.item.id)) base += l.item.price * l.qty;
      });
      if (!base) return;
      var amt = o.type === "percent" ? Math.round((base * (+o.value || 0)) / 100) : Math.min(+o.value || 0, base);
      if (!bestPF || amt > bestPF.amount) bestPF = { title: o.title, amount: amt, id: o.id };
    });
    if (bestPF && bestPF.amount > 0) parts[bestPF.id] = { title: bestPF.title, amount: bestPF.amount };

    var discounts = Object.keys(parts).map(function (k) { return parts[k]; }).filter(function (p) { return p.amount > 0; });
    var discount = discounts.reduce(function (s, p) { return s + p.amount; }, 0);
    if (discount > subtotal) discount = subtotal;
    var codeApplied = !!(code && codeOffers.some(function (o) { return parts[o.id] && parts[o.id].amount > 0; }));
    if (code && codeOffers.length && !codeApplied && !codeMessage) codeMessage = "This code does not apply to the items in your cart";

    return { subtotal: subtotal, count: count, discount: discount, discounts: discounts, codeApplied: codeApplied, codeMessage: codeMessage };
  }

  // orderType: "delivery" | "pickup"
  function delivery(subtotal, orderType, d) {
    if (orderType !== "delivery") return { available: true, charge: 0, free: false, toFree: 0 };
    if (!d || !d.enabled) return { available: false, charge: 0, free: false, toFree: 0 };
    var free = subtotal >= (d.freeMin || 0);
    return { available: true, free: free, charge: free ? 0 : +d.charge || 0, toFree: free ? 0 : d.freeMin - subtotal };
  }

  function offerSummary(o, items) {
    var names = (o.productIds || []).map(function (id) {
      var it = items.filter(function (x) { return x.id === id; })[0];
      return it ? it.name : null;
    }).filter(Boolean);
    var scope = names.length ? " on " + names.join(", ") : " on all items";
    if (o.type === "percent") return o.value + "% off" + scope;
    if (o.type === "flat") return "₹" + o.value + " off" + scope;
    if (o.type === "bxgy") return "Buy " + o.buy + " Get " + o.get + " Free" + scope;
    if (o.type === "bundle") return o.buy + " for ₹" + o.value + scope;
    return "";
  }

  var api = { todayIST: todayIST, offerStatus: offerStatus, isActive: isActive, calc: calc, delivery: delivery, offerSummary: offerSummary, applies: applies };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.Pricing = api;
})(typeof window !== "undefined" ? window : this);
