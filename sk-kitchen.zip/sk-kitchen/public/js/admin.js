/* SK KITCHEN – owner admin panel */
(function () {
  "use strict";
  var $ = function (s, e) { return (e || document).querySelector(s); };
  var $$ = function (s, e) { return Array.prototype.slice.call((e || document).querySelectorAll(s)); };
  var esc = function (s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  };
  var rs = function (n) { return "₹" + Number(n).toLocaleString("en-IN"); };
  var uid = function () { return "x" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); };
  var TOKEN_KEY = "sk_admin_token";
  var token = ""; try { token = localStorage.getItem(TOKEN_KEY) || ""; } catch (e) {}
  var data = null, tab = "menu", menuFilter = "all";
  var root = $("#root");

  function toast(msg, bad) {
    var t = $("#toast"); t.textContent = msg; t.style.background = bad ? "#a81d1d" : "#111"; t.classList.add("show");
    clearTimeout(toast.t); toast.t = setTimeout(function () { t.classList.remove("show"); }, 2400);
  }
  function api(path, method, body) {
    var headers = { "Content-Type": "application/json" };
    if (token) headers.Authorization = "Bearer " + token;
    return fetch("/api/" + path, { method: method || "GET", headers: headers, body: body ? JSON.stringify(body) : undefined, cache: "no-store" })
      .then(function (r) {
        return r.json().catch(function () { return {}; }).then(function (j) {
          if (r.status === 401 && path !== "login") { logout(); throw new Error("Session expired. Please log in again."); }
          if (!r.ok) throw new Error(j.error || "Something went wrong");
          return j;
        });
      });
  }
  function persist(okMsg) {
    return api("save", "POST", data).then(function (r) {
      data = r.data;
      toast(okMsg || "Saved ✓");
    }).catch(function (e) { toast("Not saved: " + e.message, true); throw e; });
  }
  function logout() {
    token = ""; try { localStorage.removeItem(TOKEN_KEY); } catch (e) {}
    renderLogin();
  }

  /* ---------- login ---------- */
  function renderLogin(msg) {
    root.innerHTML = '<div class="login"><form class="box card2" id="lf"><div class="logo">SK</div><h1>Owner Login</h1><p>SK KITCHEN admin panel</p>' +
      '<div class="pw"><input class="in" id="pw" type="password" placeholder="Enter owner password" autocomplete="current-password" required><button type="button" id="eye" aria-label="Show password">👁️</button></div>' +
      '<div class="err" id="lerr" style="margin:8px 0">' + esc(msg || "") + '</div><button class="btn btn-red" style="width:100%" id="lb">Login</button>' +
      '<p style="margin:14px 0 0"><a href="/" style="color:var(--red);font-weight:700">← Back to website</a></p></form></div>';
    $("#eye").onclick = function () { var p = $("#pw"); p.type = p.type === "password" ? "text" : "password"; };
    $("#lf").onsubmit = function (e) {
      e.preventDefault();
      var b = $("#lb"); b.disabled = true; b.textContent = "Checking…";
      api("login", "POST", { password: $("#pw").value }).then(function (r) {
        token = r.token; try { localStorage.setItem(TOKEN_KEY, token); } catch (e2) {}
        start();
      }).catch(function (err) {
        $("#lerr").textContent = err.message; b.disabled = false; b.textContent = "Login";
      });
    };
  }

  /* ---------- shell ---------- */
  function start() {
    root.innerHTML = '<div class="login"><div class="box" style="color:#fff">Loading…</div></div>';
    api("data").then(function (d) { data = d; renderShell(); }).catch(function (e) { if (token) root.innerHTML = '<div class="login"><div class="box card2"><p>' + esc(e.message) + '</p><button class="btn btn-red" onclick="location.reload()">Retry</button></div></div>'; });
  }
  var TABS = [["menu", "🍔", "Menu"], ["offers", "🎁", "Offers"], ["delivery", "🛵", "Delivery"], ["website", "🌐", "Website"], ["account", "👤", "Account"]];
  function renderShell() {
    root.innerHTML = '<header class="ah"><div class="wrap"><div class="t"><span class="logo" style="width:34px;height:34px;font-size:13px">SK</span><div>Owner Panel<small>' + esc(data.settings.name) + '</small></div></div><a href="/" target="_blank">View site ↗</a></div></header>' +
      '<div class="pg" id="pg"></div><nav class="tabs">' + TABS.map(function (t) { return '<button data-tab="' + t[0] + '"><span>' + t[1] + "</span>" + t[2] + "</button>"; }).join("") + "</nav>";
    $$(".tabs button").forEach(function (b) { b.onclick = function () { tab = b.dataset.tab; render(); window.scrollTo(0, 0); }; });
    render();
  }
  function render() {
    $$(".tabs button").forEach(function (b) { b.classList.toggle("on", b.dataset.tab === tab); });
    ({ menu: renderMenu, offers: renderOffers, delivery: renderDelivery, website: renderWebsite, account: renderAccount })[tab]();
  }
  var pg = function () { return $("#pg"); };
  var catName = function (id) { var c = data.categories.filter(function (x) { return x.id === id; })[0]; return c ? c.name : "—"; };
  var vm = function (it) { return '<span class="vm' + (it.veg ? "" : " nv") + '"></span>'; };

  /* ---------- modal ---------- */
  function modal(title, bodyHtml, opts) {
    opts = opts || {};
    closeModal(true);
    var ov = document.createElement("div"); ov.className = "mov"; ov.id = "mov";
    var sh = document.createElement("div"); sh.className = "msheet"; sh.id = "msheet";
    sh.innerHTML = '<div class="sheet-h"><h3>' + esc(title) + '</h3><button class="x" type="button" data-close aria-label="Close">✕</button></div><form id="mform" novalidate><div class="mb">' + bodyHtml + '<div class="err" id="merr"></div></div><div class="mf"><button type="button" class="btn btn-ghost" data-close>Cancel</button><button class="btn btn-green" id="msave">' + esc(opts.save || "Save") + "</button></div></form>";
    document.body.appendChild(ov); document.body.appendChild(sh); document.body.style.overflow = "hidden";
    requestAnimationFrame(function () { ov.classList.add("show"); sh.classList.add("show"); });
    ov.onclick = function () { closeModal(); };
    $$("[data-close]", sh).forEach(function (b) { b.onclick = function () { closeModal(); }; });
    $("#mform").onsubmit = function (e) {
      e.preventDefault();
      var btn = $("#msave"); $("#merr").textContent = "";
      var res;
      try { res = opts.onSubmit($("#mform")); } catch (err) { $("#merr").textContent = err.message; return; }
      btn.disabled = true;
      Promise.resolve(res).then(function () { closeModal(); render(); }).catch(function (err) { $("#merr").textContent = err.message || "Could not save"; btn.disabled = false; });
    };
    if (opts.init) opts.init(sh);
  }
  function closeModal(now) {
    var ov = $("#mov"), sh = $("#msheet");
    if (!ov) return;
    document.body.style.overflow = "";
    if (now) { ov.remove(); sh.remove(); return; }
    ov.classList.remove("show"); sh.classList.remove("show");
    setTimeout(function () { ov.remove(); sh.remove(); }, 300);
  }
  var field = function (label, inner, hint) { return '<label class="f">' + label + "</label>" + inner + (hint ? '<div class="hint">' + hint + "</div>" : ""); };
  var sw = function (name, on) { return '<label class="sw"><input type="checkbox" name="' + name + '"' + (on ? " checked" : "") + "><i></i></label>"; };

  /* ---------- photo upload ---------- */
  function resizeImage(file, max) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onerror = function () { rej(new Error("Could not read this photo")); };
      r.onload = function () {
        var im = new Image();
        im.onerror = function () { rej(new Error("Could not read this photo")); };
        im.onload = function () {
          var k = Math.min(1, max / Math.max(im.width, im.height));
          var w = Math.round(im.width * k), h = Math.round(im.height * k);
          var c = document.createElement("canvas"); c.width = w; c.height = h;
          var x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, w, h); x.drawImage(im, 0, 0, w, h);
          var url = c.toDataURL("image/jpeg", 0.82);
          res({ url: url, b64: url.split(",")[1] });
        };
        im.src = r.result;
      };
      r.readAsDataURL(file);
    });
  }
  function imageField(name, current, big) {
    return '<div class="imgbox"><div class="thumb" id="prev-' + name + '"' + (big ? ' style="width:140px;height:80px"' : "") + ">" + (current ? '<img src="' + esc(current) + '" alt="">' : "📷") + "</div><div>" +
      '<input type="hidden" name="' + name + '" value="' + esc(current || "") + '"><input type="file" accept="image/*" id="file-' + name + '" class="hide">' +
      '<button type="button" class="btn btn-ghost" style="padding:9px 14px;font-size:13px" data-pick="' + name + '">📷 Choose photo</button> ' +
      '<button type="button" class="btn" style="padding:9px 12px;font-size:13px;color:var(--red)" data-clear="' + name + '">Remove</button><div class="hint" id="st-' + name + '">JPG or PNG. Resized automatically.</div></div></div>';
  }
  function wireImages(sh, big) {
    $$("[data-pick]", sh).forEach(function (b) { b.onclick = function () { $("#file-" + b.dataset.pick).click(); }; });
    $$("[data-clear]", sh).forEach(function (b) {
      b.onclick = function () { var n = b.dataset.clear; $('input[name="' + n + '"]', sh).value = ""; $("#prev-" + n).innerHTML = "📷"; $("#st-" + n).textContent = "Photo removed (tap Save)"; };
    });
    $$('input[type=file]', sh).forEach(function (f) {
      f.onchange = function () {
        var n = f.id.replace("file-", ""), file = f.files[0]; if (!file) return;
        var st = $("#st-" + n); st.textContent = "Uploading…";
        resizeImage(file, big ? 1400 : 900).then(function (r) {
          return api("image", "POST", { type: "image/jpeg", data: r.b64 }).then(function (j) {
            $('input[name="' + n + '"]', sh).value = j.url;
            $("#prev-" + n).innerHTML = '<img src="' + r.url + '" alt="">'; st.textContent = "Uploaded ✓ (tap Save)";
          });
        }).catch(function (e) { st.textContent = "Failed: " + e.message; });
      };
    });
  }

  /* ---------- MENU ---------- */
  function renderMenu() {
    var items = data.items.filter(function (i) { return menuFilter === "all" || i.categoryId === menuFilter; });
    var h = "<h2>Menu</h2><div class=\"sub\">Tap the switch to show or hide an item instantly.</div>" +
      '<div class="bar-actions"><button class="btn btn-green" data-a="add-item">＋ Add Item</button><button class="btn btn-ghost" data-a="cats">📂 Categories</button></div>' +
      '<div class="chips" style="position:static;background:none;border:0;margin:0 -16px 8px"><div class="wrap" style="max-width:none;padding:0 16px"><button class="chip' + (menuFilter === "all" ? " on" : "") + '" data-a="filter" data-id="all">All (' + data.items.length + ")</button>" +
      data.categories.map(function (c) { return '<button class="chip' + (menuFilter === c.id ? " on" : "") + '" data-a="filter" data-id="' + esc(c.id) + '">' + esc(c.name) + "</button>"; }).join("") + "</div></div>";
    if (!items.length) h += '<div class="empty">No items here yet. Tap “Add Item”.</div>';
    items.forEach(function (it) {
      h += '<div class="row' + (it.available ? "" : " dim") + '"><div class="thumb">' + (it.image ? '<img src="' + esc(it.image) + '" alt="">' : esc(it.emoji || "🍽️")) + '</div><div class="mid"><div class="nm">' + vm(it) + "<span>" + esc(it.name) + "</span></div>" +
        '<div class="mt"><b style="color:var(--ink)">' + rs(it.price) + "</b> · " + esc(catName(it.categoryId)) + (it.special ? " · ⭐ Special" : "") + (it.available ? "" : " · Hidden") + '</div></div><div class="acts">' +
        '<label class="sw" title="Available"><input type="checkbox" data-a="avail" data-id="' + esc(it.id) + '"' + (it.available ? " checked" : "") + "><i></i></label>" +
        '<button class="ib" data-a="edit-item" data-id="' + esc(it.id) + '" aria-label="Edit">✏️</button><button class="ib red" data-a="del-item" data-id="' + esc(it.id) + '" aria-label="Delete">🗑️</button></div></div>';
    });
    pg().innerHTML = h;
  }
  function itemModal(id) {
    if (!data.categories.length) { toast("Add a category first", true); return catsModal(); }
    var it = id ? data.items.filter(function (x) { return x.id === id; })[0] : { id: uid(), name: "", price: "", categoryId: menuFilter !== "all" ? menuFilter : data.categories[0].id, veg: true, description: "", image: "", emoji: "", available: true, special: false };
    var isNew = !id;
    var body = field("Item name *", '<input class="in" name="name" value="' + esc(it.name) + '" placeholder="e.g. Veg Crispy Wada Pav" maxlength="80">') +
      '<div class="grid2"><div>' + field("Price (₹) *", '<input class="in" name="price" type="number" inputmode="numeric" min="0" step="1" value="' + esc(it.price) + '">') + "</div><div>" +
      field("Category *", '<select class="in" name="categoryId">' + data.categories.map(function (c) { return '<option value="' + esc(c.id) + '"' + (c.id === it.categoryId ? " selected" : "") + ">" + esc(c.name) + "</option>"; }).join("") + "</select>") + "</div></div>" +
      field("Veg / Non-Veg", '<div class="radio"><label><input type="radio" name="veg" value="1"' + (it.veg ? " checked" : "") + '><span class="vm"></span> Veg</label><label><input type="radio" name="veg" value="0"' + (it.veg ? "" : " checked") + '><span class="vm nv"></span> Non-Veg</label></div>') +
      field("Description", '<textarea class="in" name="description" maxlength="240" placeholder="Short tasty description">' + esc(it.description) + "</textarea>") +
      field("Photo", imageField("image", it.image)) +
      field("Emoji (shown when there is no photo)", '<input class="in" name="emoji" value="' + esc(it.emoji) + '" maxlength="4" style="width:90px;text-align:center;font-size:22px">') +
      '<div class="trow" style="margin-top:8px"><div><b>Available</b><small>Turn off if sold out</small></div>' + sw("available", it.available) + "</div>" +
      '<div class="trow"><div><b>⭐ Today’s Special</b><small>Show on top of homepage</small></div>' + sw("special", it.special) + "</div>";
    modal(isNew ? "Add Menu Item" : "Edit Item", body, {
      init: function (sh) { wireImages(sh); },
      onSubmit: function (f) {
        var v = function (n) { return f.elements[n]; };
        var name = v("name").value.trim(), price = Number(v("price").value);
        if (!name) throw new Error("Please enter the item name");
        if (v("price").value === "" || !(price >= 0)) throw new Error("Please enter a valid price");
        var next = { id: it.id, name: name, price: Math.round(price), categoryId: v("categoryId").value, veg: f.querySelector('input[name=veg]:checked').value === "1", description: v("description").value.trim(), image: v("image").value, emoji: v("emoji").value.trim(), available: v("available").checked, special: v("special").checked };
        if (isNew) data.items.push(next); else data.items = data.items.map(function (x) { return x.id === it.id ? next : x; });
        return persist(isNew ? "Item added ✓" : "Item updated ✓");
      }
    });
  }
  function catsModal() {
    var list = data.categories.map(function (c) { return { id: c.id, name: c.name, emoji: c.emoji }; });
    function body() {
      return list.map(function (c, i) {
        return '<div class="crow" data-i="' + i + '"><input class="in em" data-k="emoji" value="' + esc(c.emoji) + '" maxlength="4" placeholder="🍽️"><input class="in" data-k="name" value="' + esc(c.name) + '" maxlength="50" placeholder="Category name">' +
          '<button type="button" class="ib" data-m="up">▲</button><button type="button" class="ib" data-m="down">▼</button><button type="button" class="ib red" data-m="del">🗑️</button></div>';
      }).join("") + '<button type="button" class="btn btn-ghost" id="addc" style="margin-top:6px">＋ Add category</button><div class="hint">Use ▲ ▼ to change the order shown on the website.</div>';
    }
    function sync(sh) { $$(".crow", sh).forEach(function (r) { var i = +r.dataset.i; list[i].name = $('[data-k=name]', r).value; list[i].emoji = $('[data-k=emoji]', r).value; }); }
    function draw(sh) {
      $(".mb", sh).firstChild && ($(".mb", sh).querySelector("#cwrap").innerHTML = body());
      $$(".crow [data-m]", sh).forEach(function (b) {
        b.onclick = function () {
          sync(sh); var i = +b.closest(".crow").dataset.i, m = b.dataset.m;
          if (m === "up" && i > 0) { var t = list[i]; list[i] = list[i - 1]; list[i - 1] = t; }
          if (m === "down" && i < list.length - 1) { var t2 = list[i]; list[i] = list[i + 1]; list[i + 1] = t2; }
          if (m === "del") {
            if (data.items.some(function (x) { return x.categoryId === list[i].id; })) { toast("Move or delete the items in this category first", true); return; }
            list.splice(i, 1);
          }
          draw(sh);
        };
      });
      $("#addc", sh).onclick = function () { sync(sh); list.push({ id: uid(), name: "", emoji: "" }); draw(sh); };
    }
    modal("Manage Categories", '<div id="cwrap" style="margin-top:6px"></div>', {
      init: function (sh) { draw(sh); },
      onSubmit: function (f) {
        sync(f.closest(".msheet"));
        if (list.some(function (c) { return !c.name.trim(); })) throw new Error("Every category needs a name");
        data.categories = list.map(function (c) { return { id: c.id, name: c.name.trim(), emoji: c.emoji.trim() }; });
        return persist("Categories saved ✓");
      }
    });
  }

  /* ---------- OFFERS ---------- */
  function offerText(o) { return Pricing.offerSummary(o, data.items); }
  function renderOffers() {
    var h = "<h2>Offers</h2><div class=\"sub\">Offers show on the homepage between their start and end dates.</div>" +
      '<div class="bar-actions"><button class="btn btn-green" data-a="add-offer">＋ New Offer</button></div>';
    if (!data.offers.length) h += '<div class="empty">No offers yet. Tap “New Offer”.</div>';
    data.offers.forEach(function (o) {
      var st = Pricing.offerStatus(o);
      var when = (o.start ? "From " + o.start : "No start date") + (o.end ? " to " + o.end : ", no end date");
      h += '<div class="row' + (o.enabled ? "" : " dim") + '" style="align-items:flex-start"><div class="mid"><div class="nm"><span>' + esc(o.title) + '</span></div>' +
        '<div class="mt">' + esc(offerText(o)) + (o.minOrder ? " · min " + rs(o.minOrder) : "") + (o.code ? " · code " + esc(o.code) : "") + "</div><div class=\"mt\">" + esc(when) + '</div><div style="margin-top:6px"><span class="st ' + st + '">' + st.toUpperCase() + '</span></div></div><div class="acts">' +
        '<label class="sw" title="Enable"><input type="checkbox" data-a="offer-on" data-id="' + esc(o.id) + '"' + (o.enabled ? " checked" : "") + "><i></i></label>" +
        '<button class="ib" data-a="edit-offer" data-id="' + esc(o.id) + '">✏️</button><button class="ib red" data-a="del-offer" data-id="' + esc(o.id) + '">🗑️</button></div></div>';
    });
    pg().innerHTML = h;
  }
  function offerModal(id) {
    if (!data.items.length) { toast("Add menu items first", true); return; }
    var isNew = !id;
    var o = id ? data.offers.filter(function (x) { return x.id === id; })[0] : { id: uid(), title: "", description: "", type: "percent", value: 10, buy: 2, get: 1, minOrder: 0, productIds: [], start: "", end: "", code: "", enabled: true };
    var sel = o.productIds && o.productIds.length;
    var body = field("Offer title *", '<input class="in" name="title" value="' + esc(o.title) + '" maxlength="80" placeholder="e.g. Diwali Dhamaka">') +
      field("Description", '<input class="in" name="description" value="' + esc(o.description) + '" maxlength="200" placeholder="Shown to customers">') +
      field("Offer type", '<select class="in" name="type"><option value="percent">Percentage discount (% off)</option><option value="flat">Flat discount (₹ off)</option><option value="bxgy">Buy X Get Y Free (e.g. Buy 2 Get 1)</option><option value="bundle">Combo price (e.g. 3 for ₹60)</option></select>') +
      '<div data-for="percent flat">' + field('<span id="vlabel">Discount value</span>', '<input class="in" name="value" type="number" inputmode="decimal" min="0" value="' + esc(o.value) + '">') + "</div>" +
      '<div data-for="bxgy" class="grid2"><div>' + field("Buy (qty)", '<input class="in" name="buy1" type="number" inputmode="numeric" min="1" value="' + esc(o.buy || 2) + '">') + "</div><div>" + field("Get free (qty)", '<input class="in" name="get" type="number" inputmode="numeric" min="1" value="' + esc(o.get || 1) + '">') + "</div></div>" +
      '<div data-for="bundle" class="grid2"><div>' + field("Quantity", '<input class="in" name="buy2" type="number" inputmode="numeric" min="2" value="' + esc(o.buy || 3) + '">') + "</div><div>" + field("Total price (₹)", '<input class="in" name="value2" type="number" inputmode="numeric" min="0" value="' + esc(o.value) + '">') + "</div></div>" +
      field("Apply to", '<div class="radio"><label><input type="radio" name="scope" value="all"' + (sel ? "" : " checked") + '> All items</label><label><input type="radio" name="scope" value="sel"' + (sel ? " checked" : "") + '> Selected items</label></div>') +
      '<div class="pick' + (sel ? "" : " hide") + '" id="pick">' + data.items.map(function (i) { return '<label><input type="checkbox" name="pid" value="' + esc(i.id) + '"' + (o.productIds.indexOf(i.id) > -1 ? " checked" : "") + ">" + vm(i) + esc(i.name) + " (" + rs(i.price) + ")</label>"; }).join("") + "</div>" +
      field("Minimum order (₹)", '<input class="in" name="minOrder" type="number" inputmode="numeric" min="0" value="' + esc(o.minOrder) + '">', "0 = no condition. Checked against the cart subtotal.") +
      '<div class="grid2"><div>' + field("Start date", '<input class="in" name="start" type="date" value="' + esc(o.start) + '">') + "</div><div>" + field("End date", '<input class="in" name="end" type="date" value="' + esc(o.end) + '">') + "</div></div>" +
      field("Coupon code (optional)", '<input class="in" name="code" value="' + esc(o.code) + '" maxlength="20" style="text-transform:uppercase" placeholder="Leave empty to apply automatically">', "If set, customers must type this code in the cart.") +
      '<div class="trow" style="margin-top:8px"><div><b>Offer is ON</b><small>Turn off to hide it</small></div>' + sw("enabled", o.enabled) + "</div>";
    modal(isNew ? "New Offer" : "Edit Offer", body, {
      init: function (sh) {
        var type = $('[name=type]', sh); type.value = o.type;
        var upd = function () {
          $$("[data-for]", sh).forEach(function (el) { el.classList.toggle("hide", el.dataset["for"].split(" ").indexOf(type.value) < 0); });
          $("#vlabel", sh).textContent = type.value === "flat" ? "Discount amount (₹)" : "Discount percentage (%)";
        };
        type.onchange = upd; upd();
        $$('[name=scope]', sh).forEach(function (r) { r.onchange = function () { $("#pick", sh).classList.toggle("hide", $('[name=scope]:checked', sh).value !== "sel"); }; });
      },
      onSubmit: function (f) {
        var v = function (n) { return f.elements[n]; };
        var title = v("title").value.trim(); if (!title) throw new Error("Please enter an offer title");
        var type = v("type").value, buy = 0, get = 0, value = 0;
        if (type === "percent") { value = Number(v("value").value); if (!(value > 0 && value <= 100)) throw new Error("Enter a percentage between 1 and 100"); }
        if (type === "flat") { value = Number(v("value").value); if (!(value > 0)) throw new Error("Enter a discount amount"); }
        if (type === "bxgy") { buy = Math.round(Number(v("buy1").value)); get = Math.round(Number(v("get").value)); if (!(buy >= 1 && get >= 1)) throw new Error("Enter Buy and Get quantities"); }
        if (type === "bundle") { buy = Math.round(Number(v("buy2").value)); value = Number(v("value2").value); if (!(buy >= 2) || v("value2").value === "") throw new Error("Enter combo quantity (2 or more) and total price"); }
        var pids = f.querySelector('[name=scope]:checked').value === "sel" ? $$('[name=pid]:checked', f).map(function (c) { return c.value; }) : [];
        if (f.querySelector('[name=scope]:checked').value === "sel" && !pids.length) throw new Error("Select at least one item");
        var start = v("start").value, end = v("end").value;
        if (start && end && end < start) throw new Error("End date must be after the start date");
        var next = { id: o.id, title: title, description: v("description").value.trim(), type: type, value: value, buy: buy, get: get, minOrder: Number(v("minOrder").value) || 0, productIds: pids, start: start, end: end, code: v("code").value.trim().toUpperCase(), enabled: v("enabled").checked };
        if (isNew) data.offers.push(next); else data.offers = data.offers.map(function (x) { return x.id === o.id ? next : x; });
        return persist(isNew ? "Offer created ✓" : "Offer updated ✓");
      }
    });
  }

  /* ---------- DELIVERY ---------- */
  function renderDelivery() {
    var d = data.delivery;
    pg().innerHTML = "<h2>Home Delivery</h2><div class=\"sub\">Customers see these rules on the website and at checkout.</div>" +
      '<form class="card2" id="df" novalidate><div class="trow"><div><b>Home delivery</b><small>Turn off to accept self-pickup orders only</small></div>' + sw("enabled", d.enabled) + "</div>" +
      field("Free delivery on orders of (₹) or more", '<input class="in" name="freeMin" type="number" inputmode="numeric" min="0" value="' + esc(d.freeMin) + '">', "Based on the item subtotal before discounts.") +
      field("Delivery charge below that (₹)", '<input class="in" name="charge" type="number" inputmode="numeric" min="0" value="' + esc(d.charge) + '">') +
      field("Delivery distance (KM)", '<input class="in" name="distanceKm" type="number" inputmode="decimal" min="0" step="0.5" value="' + esc(d.distanceKm) + '">') +
      field("Delivery note (optional)", '<input class="in" name="note" maxlength="160" value="' + esc(d.note) + '">') +
      '<button class="btn btn-green" style="width:100%;margin-top:16px">Save Delivery Settings</button></form>';
    $("#df").onsubmit = function (e) {
      e.preventDefault(); var f = e.target, v = function (n) { return f.elements[n]; };
      data.delivery = { enabled: v("enabled").checked, freeMin: Number(v("freeMin").value) || 0, charge: Number(v("charge").value) || 0, distanceKm: Number(v("distanceKm").value) || 0, note: v("note").value.trim() };
      persist("Delivery settings saved ✓").then(render, function () {});
    };
  }

  /* ---------- WEBSITE ---------- */
  function renderWebsite() {
    var s = data.settings, tx = function (n, label, hint, extra) { return field(label, '<input class="in" name="' + n + '" value="' + esc(s[n]) + '" ' + (extra || "") + ">", hint); };
    pg().innerHTML = "<h2>Website Settings</h2><div class=\"sub\">Name, contact details, timings and promo banner.</div>" +
      '<form class="card2" id="wf" novalidate>' + tx("name", "Restaurant name", "", 'maxlength="60"') + tx("subtitle", "Subtitle", "", 'maxlength="80"') + tx("tagline", "Tagline", "", 'maxlength="160"') +
      tx("whatsapp", "WhatsApp order number", "Orders are sent to this number. 10-digit Indian number.", 'type="tel" inputmode="numeric" maxlength="15"') +
      tx("phone", "Call number", "", 'type="tel" inputmode="numeric" maxlength="15"') +
      field("Address", '<textarea class="in" name="address" maxlength="200">' + esc(s.address) + "</textarea>") +
      tx("mapsLink", "Google Maps link (optional)", "", 'inputmode="url" placeholder="https://maps.app.goo.gl/..."') +
      '<div class="grid2"><div>' + tx("openTime", "Opens at", "", 'type="time"') + "</div><div>" + tx("closeTime", "Closes at", "", 'type="time"') + "</div></div>" +
      '<h3 style="margin:20px 0 4px;font-size:16px">Promotional banner</h3><div class="trow"><div><b>Show scrolling banner</b><small>Green strip at the top of the website</small></div>' + sw("bannerEnabled", s.bannerEnabled) + "</div>" +
      tx("bannerText", "Banner text", "", 'maxlength="200" placeholder="e.g. 🪔 Diwali Dhamaka Offer 1–10 Nov"') +
      field("Banner image (optional)", imageField("bannerImage", s.bannerImage, true), "A wide promo poster shown under the top section.") +
      '<button class="btn btn-green" style="width:100%;margin-top:16px">Save Website Settings</button></form>';
    wireImages(pg(), true);
    $("#wf").onsubmit = function (e) {
      e.preventDefault(); var f = e.target, v = function (n) { return f.elements[n]; };
      var wa = v("whatsapp").value.replace(/\D/g, "");
      if (wa.length < 10) { toast("Enter a valid WhatsApp number", true); return; }
      if (!v("name").value.trim()) { toast("Restaurant name is required", true); return; }
      data.settings = { name: v("name").value.trim(), subtitle: v("subtitle").value.trim(), tagline: v("tagline").value.trim(), whatsapp: wa, phone: v("phone").value.replace(/\D/g, ""), address: v("address").value.trim(), mapsLink: v("mapsLink").value.trim(), openTime: v("openTime").value || "10:00", closeTime: v("closeTime").value || "22:00", bannerEnabled: v("bannerEnabled").checked, bannerText: v("bannerText").value.trim(), bannerImage: v("bannerImage").value };
      persist("Website settings saved ✓").then(function () { $(".ah small").textContent = data.settings.name; render(); }, function () {});
    };
  }

  /* ---------- ACCOUNT ---------- */
  function renderAccount() {
    pg().innerHTML = "<h2>Account & Backup</h2><div class=\"sub\"></div>" +
      '<div class="card2"><h3>🔐 Owner password</h3><p style="font-size:13.5px;color:var(--muted)">The password is stored safely in Netlify, never in the website code. To change it: Netlify → your site → <b>Site configuration → Environment variables → ADMIN_PASSWORD</b>, edit it, then redeploy.</p></div>' +
      '<div class="card2"><h3>💾 Backup</h3><p style="font-size:13.5px;color:var(--muted);margin-bottom:10px">Download your menu, offers and settings as a file, or restore from one.</p><div class="bar-actions" style="margin:0"><button class="btn btn-ghost" data-a="backup">⬇️ Download backup</button><button class="btn btn-ghost" data-a="restore">⬆️ Restore backup</button><input type="file" id="rf" accept="application/json,.json" class="hide"></div></div>' +
      '<div class="card2"><button class="btn btn-red" style="width:100%" data-a="logout">Log out</button></div>';
    $("#rf").onchange = function (e) {
      var file = e.target.files[0]; if (!file) return;
      var r = new FileReader();
      r.onload = function () {
        try { var d = JSON.parse(r.result); if (!d.items || !d.categories) throw 0; if (!confirm("Replace your current menu, offers and settings with this backup?")) return; data = d; persist("Backup restored ✓").then(render, function () {}); }
        catch (err) { toast("That is not a valid backup file", true); }
      };
      r.readAsText(file);
    };
  }

  /* ---------- events ---------- */
  document.addEventListener("click", function (e) {
    var el = e.target.closest("[data-a]"); if (!el || el.tagName === "INPUT") return;
    var a = el.dataset.a, id = el.dataset.id;
    if (a === "filter") { menuFilter = id; renderMenu(); }
    else if (a === "add-item") itemModal();
    else if (a === "edit-item") itemModal(id);
    else if (a === "del-item") {
      var it = data.items.filter(function (x) { return x.id === id; })[0];
      if (it && confirm("Delete “" + it.name + "”? This cannot be undone.")) { data.items = data.items.filter(function (x) { return x.id !== id; }); data.offers.forEach(function (o) { o.productIds = o.productIds.filter(function (p) { return p !== id; }); }); persist("Item deleted").then(render, function () {}); }
    }
    else if (a === "cats") catsModal();
    else if (a === "add-offer") offerModal();
    else if (a === "edit-offer") offerModal(id);
    else if (a === "del-offer") {
      var o = data.offers.filter(function (x) { return x.id === id; })[0];
      if (o && confirm("Delete offer “" + o.title + "”?")) { data.offers = data.offers.filter(function (x) { return x.id !== id; }); persist("Offer deleted").then(render, function () {}); }
    }
    else if (a === "logout") logout();
    else if (a === "backup") {
      var blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      var link = document.createElement("a"); link.href = URL.createObjectURL(blob); link.download = "sk-kitchen-backup-" + Pricing.todayIST() + ".json"; link.click();
    }
    else if (a === "restore") $("#rf").click();
  });
  document.addEventListener("change", function (e) {
    var el = e.target; if (!el.dataset || !el.dataset.a) return;
    if (el.dataset.a === "avail") {
      var it = data.items.filter(function (x) { return x.id === el.dataset.id; })[0]; if (!it) return;
      it.available = el.checked; persist(it.available ? "Item is now available ✓" : "Item hidden ✓").then(renderMenu, function () { it.available = !el.checked; renderMenu(); });
    } else if (el.dataset.a === "offer-on") {
      var o = data.offers.filter(function (x) { return x.id === el.dataset.id; })[0]; if (!o) return;
      o.enabled = el.checked; persist(o.enabled ? "Offer is ON ✓" : "Offer is OFF ✓").then(renderOffers, function () { o.enabled = !el.checked; renderOffers(); });
    }
  });

  if (token) start(); else renderLogin();
})();
