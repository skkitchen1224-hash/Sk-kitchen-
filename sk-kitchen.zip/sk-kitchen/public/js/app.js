/* SK KITCHEN – customer storefront */
(function () {
  "use strict";
  var $ = function (s, e) { return (e || document).querySelector(s); };
  var $$ = function (s, e) { return Array.prototype.slice.call((e || document).querySelectorAll(s)); };
  var esc = function (s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  };
  var rs = function (n) { return "₹" + Number(n).toLocaleString("en-IN"); };
  var MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  var fmtDate = function (d) { var p = d.split("-"); return +p[2] + " " + MON[+p[1] - 1]; };
  var fmt12 = function (t) { var h = +t.slice(0, 2), m = t.slice(3); return ((h + 11) % 12 + 1) + (m === "00" ? "" : ":" + m) + (h < 12 ? " AM" : " PM"); };
  var store = {
    get: function (k, d) { try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  };
  var ICON_WA = '<svg viewBox="0 0 24 24"><path d="M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.28-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.64.07-.3-.15-1.26-.46-2.4-1.48-.88-.79-1.48-1.76-1.65-2.06-.17-.3-.02-.46.13-.6.14-.14.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.61-.92-2.21-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.21 3.07c.15.2 2.1 3.2 5.08 4.49.7.3 1.26.49 1.7.63.72.23 1.36.2 1.87.12.57-.08 1.76-.72 2-1.42.25-.7.25-1.29.17-1.41-.07-.13-.27-.2-.57-.35M12.05 21.8h-.01a9.87 9.87 0 0 1-5.03-1.38l-.36-.21-3.74.98 1-3.65-.24-.37a9.86 9.86 0 0 1-1.51-5.26c0-5.45 4.44-9.89 9.89-9.89 2.64 0 5.12 1.03 6.99 2.9a9.83 9.83 0 0 1 2.89 7c0 5.45-4.44 9.88-9.88 9.88M20.46 3.49A11.8 11.8 0 0 0 12.05 0C5.5 0 .16 5.34.16 11.89c0 2.1.55 4.14 1.59 5.95L.06 24l6.3-1.65a11.9 11.9 0 0 0 5.69 1.45h.01c6.55 0 11.89-5.34 11.89-11.89 0-3.18-1.24-6.17-3.48-8.42"/></svg>';

  var data = null;
  var cart = store.get("sk_cart", {});
  var cust = store.get("sk_cust", {});
  var coupon = "";
  var orderType = "delivery";
  var step = "cart";
  var errors = {};
  var lastWaUrl = "";

  /* ---------- load ---------- */
  function load() {
    return fetch("/api/data", { cache: "no-store" })
      .then(function (r) { if (!r.ok) throw 0; return r.json(); })
      .catch(function () { return fetch("/defaults.json").then(function (r) { return r.json(); }); })
      .then(function (d) {
        data = d;
        pruneCart();
        if (!data.delivery.enabled) orderType = "pickup";
        renderAll();
      })
      .catch(function () {
        $("#app").innerHTML = '<div class="wrap" style="padding-top:40px"><div class="empty">Could not load the menu. Please check your internet and refresh.</div></div>';
      });
  }
  function pruneCart() {
    Object.keys(cart).forEach(function (id) {
      var it = item(id);
      if (!it || !it.available || !(cart[id] > 0)) delete cart[id];
    });
    store.set("sk_cart", cart);
  }
  function item(id) { return data.items.filter(function (i) { return i.id === id; })[0]; }
  function lines() {
    return Object.keys(cart).map(function (id) { return { item: item(id), qty: cart[id] }; }).filter(function (l) { return l.item; });
  }
  function compute() {
    var ls = lines();
    var c = Pricing.calc(ls, data, { code: coupon });
    var d = Pricing.delivery(c.subtotal, orderType, data.delivery);
    return { lines: ls, c: c, d: d, total: c.subtotal - c.discount + d.charge };
  }

  /* ---------- helpers ---------- */
  function waNumber(n) {
    n = String(n || "").replace(/\D/g, "");
    if (n.length === 10) return "91" + n;
    if (n.length === 11 && n[0] === "0") return "91" + n.slice(1);
    return n;
  }
  function isOpenNow(s) {
    var now = new Date().toLocaleTimeString("en-GB", { timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit" });
    var o = s.openTime, c = s.closeTime;
    return o <= c ? now >= o && now < c : now >= o || now < c;
  }
  function mapsUrl() {
    return data.settings.mapsLink || "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(data.settings.address);
  }
  function toast(msg) {
    var t = $("#toast"); t.textContent = msg; t.classList.add("show");
    clearTimeout(toast.t); toast.t = setTimeout(function () { t.classList.remove("show"); }, 2200);
  }

  /* ---------- render: page ---------- */
  function vm(it) { return '<span class="vm' + (it.veg ? "" : " nv") + '" title="' + (it.veg ? "Veg" : "Non-Veg") + '"></span>'; }
  function ctl(it) {
    if (!it.available) return '<span class="soldout">Not available</span>';
    var q = cart[it.id] || 0;
    if (!q) return '<button class="add" data-a="add" data-id="' + esc(it.id) + '">ADD</button>';
    return '<div class="step"><button data-a="dec" data-id="' + esc(it.id) + '" aria-label="Remove one">−</button><b>' + q + '</b><button data-a="inc" data-id="' + esc(it.id) + '" aria-label="Add one">+</button></div>';
  }
  function cardHtml(it, showRibbon) {
    var cat = data.categories.filter(function (c) { return c.id === it.categoryId; })[0];
    var ph = it.emoji || (cat && cat.emoji) || "🍽️";
    var pic = it.image ? '<img src="' + esc(it.image) + '" alt="' + esc(it.name) + '" loading="lazy" decoding="async">' : '<span class="ph">' + esc(ph) + "</span>";
    return '<article class="card rv' + (it.available ? "" : " off") + '"><div class="card-img' + (it.veg ? " v" : "") + '">' + pic +
      (showRibbon && it.special ? '<span class="ribbon">⭐ SPECIAL</span>' : "") + '</div><div class="card-body"><h4>' + vm(it) + "<span>" + esc(it.name) + "</span></h4><p>" +
      esc(it.description) + '</p><div class="foot"><span class="price">' + rs(it.price) + '</span><span class="ctl" data-id="' + esc(it.id) + '">' + ctl(it) + "</span></div></div></article>";
  }
  function offerCards() {
    var today = Pricing.todayIST();
    var list = data.offers.filter(function (o) { var s = Pricing.offerStatus(o, today); return s === "active" || (s === "scheduled" && o.start); });
    list.sort(function (a, b) { return (Pricing.isActive(b, today) ? 1 : 0) - (Pricing.isActive(a, today) ? 1 : 0); });
    if (!list.length) return '<div class="empty rv">🪔 New offers coming soon. Stay tuned!</div>';
    return '<div class="offers">' + list.map(function (o) {
      var soon = !Pricing.isActive(o, today);
      var tags = ['<span class="tagp">' + esc(Pricing.offerSummary(o, data.items)) + "</span>"];
      if (soon) tags.unshift('<span class="tagp">⏳ Starts ' + fmtDate(o.start) + "</span>");
      if (o.end && !soon) tags.push('<span class="tagp">Till ' + fmtDate(o.end) + "</span>");
      if (o.minOrder) tags.push('<span class="tagp">Min order ' + rs(o.minOrder) + "</span>");
      if (o.code) tags.push('<span class="tagp">Code: ' + esc(o.code) + "</span>");
      return '<div class="offer rv"><h4>' + esc(o.title) + "</h4>" + (o.description ? "<p>" + esc(o.description) + "</p>" : "") + '<div class="meta">' + tags.join("") + "</div></div>";
    }).join("") + "</div>";
  }
  function renderAll() {
    var s = data.settings, d = data.delivery;
    document.title = s.name + " – " + (s.subtitle || "Order Online");
    $("#brandName").textContent = s.name;

    $("#strip").innerHTML = s.bannerEnabled && s.bannerText
      ? '<div class="strip"><div class="track"><span>' + esc(s.bannerText) + "</span><span>" + esc(s.bannerText) + "</span><span>" + esc(s.bannerText) + "</span><span>" + esc(s.bannerText) + "</span></div></div>" : "";

    var open = isOpenNow(s);
    var h = '<div class="hero" id="top"><span class="float f1">🥟</span><span class="float f2">🌶️</span><span class="float f3">🍔</span><div class="wrap">' +
      '<span class="open-pill"><i class="dot ' + (open ? "on" : "off") + '"></i>' + (open ? "Open now" : "Closed now") + " · " + fmt12(s.openTime) + " – " + fmt12(s.closeTime) + "</span>" +
      "<h1>" + esc(s.name).replace(/^(\S+)/, "<b>$1</b>") + "</h1><h2>" + esc(s.subtitle).replace(/MOMOS/i, "<em>MOMOS</em>") + "</h2>" +
      '<p class="tag">' + esc(s.tagline) + "</p>" +
      '<div class="loc">📍 ' + esc(s.address) + "</div>" +
      '<div class="cta"><a class="btn btn-red" href="#menu">🍽️ Order Now</a><a class="btn btn-green" href="https://wa.me/' + waNumber(s.whatsapp) + '" target="_blank" rel="noopener">' + ICON_WA + "WhatsApp</a></div></div></div>";
    if (s.bannerImage) h += '<div class="wrap"><div class="promo-img rv"><img src="' + esc(s.bannerImage) + '" alt="Offer banner"></div></div>';

    var specials = data.items.filter(function (i) { return i.special && i.available; });
    if (specials.length) h += '<section id="special"><div class="wrap"><div class="sec-h"><span class="bar"></span><h3>⭐ Today’s Special</h3></div><div class="grid">' + specials.map(function (i) { return cardHtml(i, false); }).join("") + "</div></div></section>";

    h += '<section id="offers"><div class="wrap"><div class="sec-h"><span class="bar"></span><h3>🎁 Special Offers</h3></div>' + offerCards() + "</div></section>";

    var cats = data.categories.filter(function (c) { return data.items.some(function (i) { return i.categoryId === c.id; }); });
    h += '<div class="chips" id="menu"><div class="wrap">' + cats.map(function (c, i) { return '<button class="chip' + (i ? "" : " on") + '" data-a="chip" data-id="' + esc(c.id) + '">' + esc((c.emoji || "") + " " + c.name).trim() + "</button>"; }).join("") + "</div></div>";
    cats.forEach(function (c) {
      var its = data.items.filter(function (i) { return i.categoryId === c.id; });
      var allVeg = its.every(function (i) { return i.veg; });
      h += '<section class="cat" id="cat-' + esc(c.id) + '"><div class="wrap"><div class="sec-h' + (allVeg ? " veg" : "") + '"><span class="bar"></span><h3>' + esc((c.emoji || "") + " " + c.name).trim() + "</h3><small>" + its.length + ' items</small></div><div class="grid">' + its.map(function (i) { return cardHtml(i, true); }).join("") + "</div></div></section>";
    });
    if (!cats.length) h += '<section><div class="wrap"><div class="empty">Menu will be updated soon.</div></div></section>';

    var dl = d.enabled
      ? '<div class="rows"><div><i>🛵</i><span><b>Home delivery</b> <span class="pill-ok">Available</span></span></div>' +
        "<div><i>✅</i><span>Orders of <b>" + rs(d.freeMin) + " or more</b>: <b style=\"color:var(--green-d)\">FREE delivery</b></span></div>" +
        "<div><i>💸</i><span>Orders below " + rs(d.freeMin) + ": delivery charge <b>" + rs(d.charge) + "</b></span></div>" +
        "<div><i>📏</i><span>Delivery within <b>" + d.distanceKm + " KM</b> of " + esc(s.address.split(",")[0]) + "</span></div>" +
        (d.note ? "<div><i>💬</i><span>" + esc(d.note) + "</span></div>" : "") + "</div>"
      : '<div class="rows"><div><i>🛵</i><span><b>Home delivery</b> <span class="pill-no">Currently unavailable</span></span></div><div><i>🏪</i><span>Please order for <b>self pickup</b> from our stall.</span></div></div>';
    h += '<section id="delivery"><div class="wrap"><div class="sec-h"><span class="bar"></span><h3>🛵 Home Delivery</h3></div><div class="box rv">' + dl + "</div></div></section>";

    h += '<section id="contact"><div class="wrap"><div class="sec-h"><span class="bar"></span><h3>📞 Contact &amp; WhatsApp Order</h3></div><div class="info">' +
      '<div class="box rv"><h4>' + esc(s.name) + '</h4><div class="rows"><div><i>📍</i><span>' + esc(s.address) + "</span></div><div><i>🕒</i><span>" + fmt12(s.openTime) + " – " + fmt12(s.closeTime) + " (daily)</span></div>" +
      (s.phone ? '<div><i>📱</i><span>+91 ' + esc(s.phone.slice(-10)) + "</span></div>" : "") + "</div></div>" +
      '<div class="box rv"><h4>Order on WhatsApp</h4><p style="font-size:13.5px;color:var(--muted);margin-bottom:12px">Add items to your cart and tap “Place Order on WhatsApp”, or message us directly.</p><div class="cta">' +
      '<a class="btn btn-green" href="https://wa.me/' + waNumber(s.whatsapp) + '" target="_blank" rel="noopener">' + ICON_WA + "Chat on WhatsApp</a>" +
      (s.phone ? '<a class="btn btn-ghost" href="tel:+' + waNumber(s.phone) + '">📞 Call</a>' : "") +
      '<a class="btn btn-ghost" href="' + esc(mapsUrl()) + '" target="_blank" rel="noopener">🗺️ Map</a></div></div></div></div></section>';
    $("#app").innerHTML = h;

    $("#foot").innerHTML = '<div class="wrap"><b>' + esc(s.name) + "</b><br>" + esc(s.tagline) + "<br>© " + new Date().getFullYear() + " " + esc(s.name) + "</div>";
    observe();
    updateBar();
  }

  /* ---------- scroll effects ---------- */
  var rvObs, spyObs;
  function observe() {
    if (rvObs) rvObs.disconnect();
    if (spyObs) spyObs.disconnect();
    if ("IntersectionObserver" in window) {
      rvObs = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("in"); rvObs.unobserve(e.target); } }); }, { threshold: 0.08 });
      $$(".rv").forEach(function (el) { rvObs.observe(el); });
      spyObs = new IntersectionObserver(function (es) {
        es.forEach(function (e) {
          if (!e.isIntersecting) return;
          var id = e.target.id.replace("cat-", "");
          $$(".chip").forEach(function (c) { c.classList.toggle("on", c.dataset.id === id); });
          var on = $(".chip.on"); if (on && on.scrollIntoView) { var box = on.parentNode; box.scrollTo({ left: on.offsetLeft - 20, behavior: "smooth" }); }
        });
      }, { rootMargin: "-120px 0px -65% 0px" });
      $$("section.cat").forEach(function (el) { spyObs.observe(el); });
    } else { $$(".rv").forEach(function (el) { el.classList.add("in"); }); }
  }

  /* ---------- cart ---------- */
  function cartCount() { return Object.keys(cart).reduce(function (s, k) { return s + cart[k]; }, 0); }
  function updateBar() {
    var n = cartCount();
    var b = $("#cartN"); b.hidden = !n; b.textContent = n;
    var open = $("#sheet").classList.contains("show");
    if (n) { var t = compute(); $("#cbItems").textContent = n + (n > 1 ? " items" : " item"); $("#cbTotal").textContent = rs(t.c.subtotal - t.c.discount); }
    $("#cartbar").classList.toggle("show", n > 0 && !open);
  }
  function refreshControls() {
    $$(".ctl").forEach(function (el) { var it = item(el.dataset.id); if (it) el.innerHTML = ctl(it); });
    updateBar();
  }
  function setQty(id, q) {
    var it = item(id); if (!it || !it.available) return;
    if (q <= 0) delete cart[id]; else cart[id] = Math.min(q, 50);
    store.set("sk_cart", cart);
    var b = $("#cartN"); b.classList.remove("bump"); void b.offsetWidth; b.classList.add("bump");
    refreshControls();
    if ($("#sheet").classList.contains("show") && step === "cart") renderSheet();
  }
  function openCart() {
    if (!cartCount() && step !== "done") { toast("Your cart is empty. Add something tasty! 😋"); return; }
    if (step === "done" && !cartCount()) step = "cart";
    $("#sheet").classList.add("show"); $("#ov").classList.add("show");
    document.body.style.overflow = "hidden";
    renderSheet(); updateBar();
  }
  function closeCart() {
    $("#sheet").classList.remove("show"); $("#ov").classList.remove("show");
    document.body.style.overflow = "";
    if (step === "details") step = "cart";
    updateBar();
  }

  function billHtml(t) {
    var h = '<div class="bill"><div><span>Subtotal</span><span>' + rs(t.c.subtotal) + "</span></div>";
    t.c.discounts.forEach(function (p) { h += '<div class="disc"><span>🎉 ' + esc(p.title) + "</span><span>−" + rs(p.amount) + "</span></div>"; });
    if (orderType === "delivery") h += "<div><span>Delivery charge</span><span>" + (t.d.free ? '<b style="color:var(--green-d)">FREE</b>' : rs(t.d.charge)) + "</span></div>";
    h += '<div class="tot"><span>Grand Total</span><span>' + rs(t.total) + "</span></div></div>";
    return h;
  }
  function renderSheet() {
    var sh = $("#sheet"), t = compute(), s = data.settings, dcfg = data.delivery, h;
    if (step === "done") {
      sh.innerHTML = '<div class="sheet-h"><h3>Order</h3><button class="x" data-a="closecart" aria-label="Close">✕</button></div><div class="sheet-b"><div class="done"><div class="big">✅</div><h3 style="font-size:22px;margin:8px 0">Almost done!</h3><p style="color:var(--muted);font-size:14px;margin-bottom:18px">WhatsApp should have opened with your order. Just tap <b>Send</b> there to confirm it with us.</p><a class="btn btn-green" href="' + esc(lastWaUrl) + '" target="_blank" rel="noopener" style="width:100%">' + ICON_WA + 'Open WhatsApp again</a><button class="btn btn-ghost" data-a="neworder" style="width:100%;margin-top:10px">Start a new order</button></div></div>';
      return;
    }
    if (!t.lines.length) { closeCart(); return; }

    if (step === "cart") {
      h = '<div class="sheet-h"><h3>🛒 Your Cart</h3><button class="x" data-a="closecart" aria-label="Close">✕</button></div><div class="sheet-b">';
      t.lines.forEach(function (l) {
        h += '<div class="line"><div class="n">' + vm(l.item) + "<span>" + esc(l.item.name) + "<small>" + rs(l.item.price) + ' each</small></span></div><div class="step"><button data-a="dec" data-id="' + esc(l.item.id) + '">−</button><b>' + l.qty + '</b><button data-a="inc" data-id="' + esc(l.item.id) + '">+</button></div><div class="amt">' + rs(l.item.price * l.qty) + "</div></div>";
      });
      var hasCode = data.offers.some(function (o) { return o.code && Pricing.isActive(o); });
      if (hasCode) {
        h += '<div class="coupon"><input class="in" id="coupon" placeholder="Have a coupon code?" value="' + esc(coupon) + '" autocapitalize="characters" style="text-transform:uppercase"><button class="btn btn-red" data-a="coupon" style="padding:0 18px">Apply</button></div>';
        if (coupon) h += '<div class="notice ' + (t.c.codeApplied ? "g" : "r") + '">' + (t.c.codeApplied ? "✅ Coupon applied!" : esc(t.c.codeMessage || "Coupon not applicable")) + "</div>";
      }
      h += '<div class="seg"><button data-a="type" data-v="delivery" class="' + (orderType === "delivery" ? "on" : "") + '"' + (dcfg.enabled ? "" : " disabled style=\"opacity:.45\"") + '>🛵 Home Delivery</button><button data-a="type" data-v="pickup" class="' + (orderType === "pickup" ? "on" : "") + '">🏪 Self Pickup</button></div>';
      if (orderType === "delivery") {
        if (t.d.free) h += '<div class="notice g">🎉 You get <b>FREE home delivery</b> (orders ' + rs(dcfg.freeMin) + "+)</div>";
        else h += '<div class="notice y">Add <b>' + rs(t.d.toFree) + "</b> more for <b>FREE delivery</b>. Delivery charge now: " + rs(dcfg.charge) + '<div class="prog"><i style="width:' + Math.min(100, Math.round((t.c.subtotal / dcfg.freeMin) * 100)) + '%"></i></div></div>';
        h += '<div style="font-size:12.5px;color:var(--muted)">📏 We deliver within ' + dcfg.distanceKm + " KM of " + esc(s.address.split(",")[0]) + ".</div>";
      } else if (!dcfg.enabled) h += '<div class="notice y">Home delivery is currently unavailable. Please pick up from our stall.</div>';
      h += billHtml(t) + '</div><div class="sheet-f"><button class="btn btn-red" data-a="next" style="width:100%">Continue to Checkout ›</button></div>';
    } else {
      h = '<div class="sheet-h"><button class="back" data-a="back">‹ Back to cart</button><button class="x" data-a="closecart" aria-label="Close">✕</button></div><div class="sheet-b"><h3 style="font-size:19px;margin-bottom:2px">Your Details</h3>' +
        '<label class="f">Your Name *</label><input class="in' + (errors.name ? " bad" : "") + '" id="f-name" autocomplete="name" placeholder="e.g. Rahul Patil" value="' + esc(cust.name || "") + '">' + (errors.name ? '<div class="err">' + errors.name + "</div>" : "") +
        '<label class="f">Mobile Number *</label><input class="in' + (errors.phone ? " bad" : "") + '" id="f-phone" type="tel" inputmode="numeric" autocomplete="tel" maxlength="14" placeholder="10-digit mobile number" value="' + esc(cust.phone || "") + '">' + (errors.phone ? '<div class="err">' + errors.phone + "</div>" : "");
      if (orderType === "delivery") {
        h += '<label class="f">Full Delivery Address *</label><textarea class="in' + (errors.address ? " bad" : "") + '" id="f-address" autocomplete="street-address" placeholder="House / flat no., building, landmark, area">' + esc(cust.address || "") + "</textarea>" + (errors.address ? '<div class="err">' + errors.address + "</div>" : "") +
          '<label class="f">Google Maps Location Link (optional)</label><input class="in" id="f-map" inputmode="url" placeholder="Paste your Google Maps link" value="' + esc(cust.map || "") + '"><button class="btn btn-ghost" data-a="geo" style="margin-top:8px;padding:9px 14px;font-size:13px">📍 Use my current location</button>';
      } else h += '<div class="notice g" style="margin-top:14px">🏪 Self pickup from <b>' + esc(s.address) + "</b></div>";
      h += '<label class="f">Special instructions (optional)</label><input class="in" id="f-note" placeholder="e.g. less spicy, extra chutney" value="' + esc(cust.note || "") + '">' +
        '<h3 style="font-size:17px;margin:20px 0 6px">Order Summary</h3>';
      t.lines.forEach(function (l) {
        h += '<div class="line" style="padding:8px 0"><div class="n">' + vm(l.item) + "<span>" + esc(l.item.name) + "<small>" + l.qty + " × " + rs(l.item.price) + '</small></span></div><div class="amt">' + rs(l.item.price * l.qty) + "</div></div>";
      });
      h += billHtml(t) + '<div style="font-size:12.5px;color:var(--muted)">💵 Pay by cash or UPI on ' + (orderType === "delivery" ? "delivery" : "pickup") + ". No online payment needed.</div></div>" +
        '<div class="sheet-f"><button class="btn btn-green" data-a="place" style="width:100%">' + ICON_WA + "Place Order on WhatsApp</button></div>";
    }
    sh.innerHTML = h;
  }

  function saveCust() {
    var g = function (id) { var e = $(id); return e ? e.value : undefined; };
    ["name", "phone", "address", "map", "note"].forEach(function (k) { var v = g("#f-" + k); if (v !== undefined) cust[k] = v; });
    store.set("sk_cust", cust);
  }
  function validate() {
    errors = {};
    var phone = String(cust.phone || "").replace(/\D/g, "").replace(/^(91|0)(?=\d{10}$)/, "");
    if (!cust.name || cust.name.trim().length < 2) errors.name = "Please enter your name";
    if (!/^[6-9]\d{9}$/.test(phone)) errors.phone = "Enter a valid 10-digit mobile number";
    if (orderType === "delivery" && (!cust.address || cust.address.trim().length < 8)) errors.address = "Please enter your full delivery address";
    return !Object.keys(errors).length;
  }
  function buildMessage(t) {
    var s = data.settings, L = [];
    var phone = String(cust.phone).replace(/\D/g, "").replace(/^(91|0)(?=\d{10}$)/, "");
    L.push("🍽️ *NEW ORDER – " + s.name + "*");
    L.push("━━━━━━━━━━━━━━");
    L.push("👤 *Name:* " + cust.name.trim());
    L.push("📱 *Mobile:* " + phone);
    L.push("🚚 *Order Type:* " + (orderType === "delivery" ? "Home Delivery" : "Self Pickup"));
    if (orderType === "delivery") {
      L.push("📍 *Address:* " + cust.address.trim().replace(/\s*\n\s*/g, ", "));
      if (cust.map && cust.map.trim()) L.push("🗺️ *Map:* " + cust.map.trim());
    }
    L.push("━━━━━━━━━━━━━━");
    L.push("*ITEMS*");
    t.lines.forEach(function (l, i) {
      L.push((i + 1) + ". " + (l.item.veg ? "🟢 " : "🔴 ") + l.item.name);
      L.push("    " + l.qty + " × " + rs(l.item.price) + " = " + rs(l.qty * l.item.price));
    });
    L.push("━━━━━━━━━━━━━━");
    L.push("Subtotal: " + rs(t.c.subtotal));
    t.c.discounts.forEach(function (p) { L.push("Offer (" + p.title + "): -" + rs(p.amount)); });
    if (!t.c.discounts.length) L.push("Discount: " + rs(0));
    if (orderType === "delivery") L.push("Delivery Charge: " + (t.d.free ? "FREE" : rs(t.d.charge)));
    L.push("*GRAND TOTAL: " + rs(t.total) + "*");
    L.push("━━━━━━━━━━━━━━");
    if (cust.note && cust.note.trim()) L.push("📝 *Note:* " + cust.note.trim());
    L.push("💵 Payment: Cash / UPI on " + (orderType === "delivery" ? "delivery" : "pickup"));
    L.push("🕒 " + new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata", day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }));
    return L.join("\n");
  }
  function place() {
    saveCust();
    if (!validate()) { renderSheet(); var bad = $(".in.bad"); if (bad) { bad.focus(); } return; }
    var t = compute();
    lastWaUrl = "https://wa.me/" + waNumber(data.settings.whatsapp) + "?text=" + encodeURIComponent(buildMessage(t));
    var w = window.open(lastWaUrl, "_blank");
    if (!w) window.location.href = lastWaUrl;
    step = "done"; renderSheet();
  }

  /* ---------- events ---------- */
  document.addEventListener("click", function (e) {
    var el = e.target.closest("[data-a]"); if (!el) return;
    var a = el.dataset.a, id = el.dataset.id;
    if (a === "add") setQty(id, 1);
    else if (a === "inc") setQty(id, (cart[id] || 0) + 1);
    else if (a === "dec") setQty(id, (cart[id] || 0) - 1);
    else if (a === "opencart") openCart();
    else if (a === "closecart") closeCart();
    else if (a === "chip") { var sec = document.getElementById("cat-" + id); if (sec) sec.scrollIntoView({ behavior: "smooth" }); }
    else if (a === "type") { if (!el.disabled) { orderType = el.dataset.v; renderSheet(); } }
    else if (a === "coupon") { coupon = ($("#coupon").value || "").trim().toUpperCase(); renderSheet(); }
    else if (a === "next") { step = "details"; errors = {}; renderSheet(); $("#sheet .sheet-b").scrollTop = 0; }
    else if (a === "back") { saveCust(); step = "cart"; renderSheet(); }
    else if (a === "place") place();
    else if (a === "neworder") { cart = {}; coupon = ""; store.set("sk_cart", cart); step = "cart"; closeCart(); refreshControls(); }
    else if (a === "geo") {
      if (!navigator.geolocation) { toast("Location not supported on this device"); return; }
      toast("Getting your location…");
      navigator.geolocation.getCurrentPosition(function (p) {
        $("#f-map").value = "https://www.google.com/maps?q=" + p.coords.latitude.toFixed(6) + "," + p.coords.longitude.toFixed(6);
        saveCust(); toast("Location added ✓");
      }, function () { toast("Could not get location. Please allow location access."); }, { enableHighAccuracy: true, timeout: 10000 });
    }
  });
  document.addEventListener("input", function (e) { if (e.target.id && e.target.id.indexOf("f-") === 0) saveCust(); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeCart(); });

  load();
  setInterval(function () { if (data) { var p = $(".open-pill"); if (p) { var o = isOpenNow(data.settings); p.querySelector(".dot").className = "dot " + (o ? "on" : "off"); } } }, 60000);
})();
