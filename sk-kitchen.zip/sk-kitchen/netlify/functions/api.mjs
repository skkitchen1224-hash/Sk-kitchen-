import { getStore } from "@netlify/blobs";
import { createHandler } from "./lib/core.mjs";

// Netlify Blobs = the built-in free database. Nothing to set up.
export default createHandler(() => ({
  data: getStore({ name: "sk-kitchen", consistency: "strong" }),
  images: getStore({ name: "sk-images", consistency: "strong" }),
}));

export const config = { path: "/api/*" };
